# INFO 2201: Computational Reasoning 2
This is the syllabus and lab notebooks for the Spring 2017 version of the "Computational Reasoning 2" course (INFO 2201) at CU Boulder's [Department of Information Science](http://www.colorado.edu/cmci/academics/information-science). It is intended as a 16-week lecture and lab format.

## To-do
* Add lab notebooks
